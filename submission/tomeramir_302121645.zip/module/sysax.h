/*** Sysax attack blcok ***/
#ifndef _SYSAX_
#define _SYSAX_

#include "fw.h"

#define XP_FOLDER_NAME_LEN 300

int check_sysax_attack(const char *data);

#endif // _SYSAX_