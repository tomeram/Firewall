/*** Stateful Inspection ***/
#ifndef _ZABBIX_
#define _ZABBIX_

#include "fw.h"

int check_zabbix_injection(const char *data);

#endif // _ZABBIX_