/*** Data Loss Prevention ***/
#ifndef _DLP_
#define _DLP_

#include "fw.h"
#include <linux/ctype.h>

int check_for_code(const char *str);

#endif // _DLP_